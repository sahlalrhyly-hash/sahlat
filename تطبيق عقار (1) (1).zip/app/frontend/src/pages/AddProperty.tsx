import { useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowRight, Plus, X, Upload, Image, MapPin } from 'lucide-react'
import { usePropertyStore } from '@/store/propertyStore'
import { useAuthStore } from '@/store/authStore'

export default function AddProperty() {
  const navigate = useNavigate()
  const { addProperty, loading } = usePropertyStore()
  const { user } = useAuthStore()
  const [form, setForm] = useState({
    title: '',
    description: '',
    type: 'apartment' as 'apartment' | 'villa' | 'land' | 'building' | 'farm',
    purpose: 'sale' as 'sale' | 'rent',
    price: '',
    city: '',
    district: '',
    phone: '',
    whatsapp: '',
    lat: '',
    lng: '',
  })
  const [imageFiles, setImageFiles] = useState<File[]>([])
  const [imagePreviews, setImagePreviews] = useState<string[]>([])
  const [error, setError] = useState('')
  const [uploading, setUploading] = useState(false)
  const [showMap, setShowMap] = useState(false)

  const MAX_IMAGES = 20

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    const newFiles = Array.from(files)
    const totalAfter = imageFiles.length + newFiles.length
    if (totalAfter > MAX_IMAGES) {
      setError(`الحد الأقصى ${MAX_IMAGES} صورة. يمكنك إضافة ${MAX_IMAGES - imageFiles.length} صور أخرى فقط.`)
      return
    }
    setError('')
    setImageFiles(prev => [...prev, ...newFiles])
    newFiles.forEach(file => {
      const reader = new FileReader()
      reader.onload = (ev) => {
        if (ev.target?.result) setImagePreviews(prev => [...prev, ev.target!.result as string])
      }
      reader.readAsDataURL(file)
    })
  }

  const removeImage = (index: number) => {
    setImageFiles(imageFiles.filter((_, i) => i !== index))
    setImagePreviews(imagePreviews.filter((_, i) => i !== index))
  }

  const handleMapClick = useCallback(() => {
    setShowMap(!showMap)
  }, [showMap])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) { navigate('/login'); return }
    if (!form.title) { setError('يرجى إدخال عنوان العقار'); return }
    if (!form.type) { setError('يرجى اختيار نوع العقار'); return }
    if (!form.price) { setError('يرجى إدخال السعر'); return }
    if (!form.city) { setError('يرجى إدخال المدينة'); return }
    if (!form.district) { setError('يرجى إدخال الحي'); return }
    if (!form.phone) { setError('يرجى إدخال رقم التواصل'); return }
    if (imageFiles.length === 0) { setError('يرجى إضافة صورة واحدة على الأقل'); return }

    setUploading(true)
    setError('')
    try {
      await addProperty({
        title: form.title,
        description: form.description,
        type: form.type,
        purpose: form.purpose,
        price: Number(form.price),
        area: 0,
        rooms: 0,
        bathrooms: 0,
        city: form.city,
        district: form.district,
        address: `${form.city} - ${form.district}`,
        lat: form.lat ? Number(form.lat) : 24.7 + Math.random() * 0.2,
        lng: form.lng ? Number(form.lng) : 46.6 + Math.random() * 0.2,
        images: [],
        videos: [],
        features: [],
        ownerId: user.id,
        ownerName: user.name,
        ownerPhone: form.phone,
        ownerWhatsapp: form.whatsapp || form.phone,
        status: 'active',
      }, imageFiles, [])
      navigate('/')
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء نشر العقار')
    } finally {
      setUploading(false)
    }
  }

  if (!user) { navigate('/login'); return null }

  const typeOptions = [
    { value: 'land', label: 'أرض', icon: '🏜️' },
    { value: 'apartment', label: 'شقة', icon: '🏢' },
    { value: 'villa', label: 'فيلا', icon: '🏡' },
    { value: 'building', label: 'عمارة', icon: '🏗️' },
    { value: 'farm', label: 'مزرعة', icon: '🌾' },
  ]

  return (
    <div className="pb-6">
      <div className="sticky top-0 z-40 bg-white border-b px-4 h-14 flex items-center gap-3 shadow-sm">
        <button onClick={() => navigate(-1)} className="p-1">
          <ArrowRight size={22} />
        </button>
        <h2 className="font-bold text-lg">إضافة عقار جديد</h2>
      </div>

      <form onSubmit={handleSubmit} className="p-4 space-y-5">
        {error && (
          <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg border border-red-200">
            {error}
          </div>
        )}

        {uploading && (
          <div className="bg-blue-50 text-blue-600 text-sm p-3 rounded-lg flex items-center gap-2 border border-blue-200">
            <Upload size={16} className="animate-bounce" />
            جاري رفع الصور ونشر العقار... يرجى الانتظار
          </div>
        )}

        {/* عنوان العقار */}
        <div>
          <label className="text-sm font-semibold text-slate-700 mb-1.5 block">عنوان العقار *</label>
          <input
            type="text"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="مثال: فيلا فاخرة في حي الملقا"
            className="w-full p-3 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            required
          />
        </div>

        {/* نوع العقار */}
        <div>
          <label className="text-sm font-semibold text-slate-700 mb-2 block">نوع العقار *</label>
          <div className="grid grid-cols-5 gap-2">
            {typeOptions.map(opt => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setForm({ ...form, type: opt.value as any })}
                className={`flex flex-col items-center gap-1 p-3 rounded-xl border-2 transition-all ${
                  form.type === opt.value
                    ? 'border-primary-500 bg-primary-50 shadow-sm'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <span className="text-2xl">{opt.icon}</span>
                <span className="text-xs font-medium">{opt.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* الغرض */}
        <div>
          <label className="text-sm font-semibold text-slate-700 mb-2 block">الغرض</label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setForm({ ...form, purpose: 'sale' })}
              className={`p-3 rounded-xl border-2 text-sm font-medium transition-all ${
                form.purpose === 'sale'
                  ? 'border-primary-500 bg-primary-50 text-primary-700'
                  : 'border-slate-200 text-slate-600'
              }`}
            >
              للبيع
            </button>
            <button
              type="button"
              onClick={() => setForm({ ...form, purpose: 'rent' })}
              className={`p-3 rounded-xl border-2 text-sm font-medium transition-all ${
                form.purpose === 'rent'
                  ? 'border-primary-500 bg-primary-50 text-primary-700'
                  : 'border-slate-200 text-slate-600'
              }`}
            >
              للإيجار
            </button>
          </div>
        </div>

        {/* السعر */}
        <div>
          <label className="text-sm font-semibold text-slate-700 mb-1.5 block">السعر (ريال) *</label>
          <input
            type="number"
            value={form.price}
            onChange={(e) => setForm({ ...form, price: e.target.value })}
            placeholder="أدخل السعر"
            className="w-full p-3 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            required
          />
        </div>

        {/* المدينة والحي */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-semibold text-slate-700 mb-1.5 block">المدينة *</label>
            <input
              type="text"
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
              placeholder="مثال: الرياض"
              className="w-full p-3 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              required
            />
          </div>
          <div>
            <label className="text-sm font-semibold text-slate-700 mb-1.5 block">الحي *</label>
            <input
              type="text"
              value={form.district}
              onChange={(e) => setForm({ ...form, district: e.target.value })}
              placeholder="مثال: الملقا"
              className="w-full p-3 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              required
            />
          </div>
        </div>

        {/* الموقع على الخريطة */}
        <div>
          <label className="text-sm font-semibold text-slate-700 mb-1.5 block">الموقع على الخريطة</label>
          <button
            type="button"
            onClick={handleMapClick}
            className="w-full p-3 rounded-xl border border-slate-200 text-sm text-right flex items-center gap-2 hover:bg-slate-50"
          >
            <MapPin size={18} className="text-primary-600" />
            <span className="text-slate-500">
              {form.lat && form.lng
                ? `تم تحديد الموقع (${Number(form.lat).toFixed(4)}, ${Number(form.lng).toFixed(4)})`
                : 'اضغط لتحديد الموقع أو أدخل الإحداثيات'}
            </span>
          </button>
          {showMap && (
            <div className="mt-2 space-y-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">خط العرض (Lat)</label>
                  <input
                    type="number"
                    step="any"
                    value={form.lat}
                    onChange={(e) => setForm({ ...form, lat: e.target.value })}
                    placeholder="24.7136"
                    className="w-full p-2 rounded-lg border border-slate-200 text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">خط الطول (Lng)</label>
                  <input
                    type="number"
                    step="any"
                    value={form.lng}
                    onChange={(e) => setForm({ ...form, lng: e.target.value })}
                    placeholder="46.6753"
                    className="w-full p-2 rounded-lg border border-slate-200 text-sm"
                  />
                </div>
              </div>
              <p className="text-xs text-slate-400">يمكنك نسخ الإحداثيات من خرائط Google</p>
            </div>
          )}
        </div>

        {/* الوصف */}
        <div>
          <label className="text-sm font-semibold text-slate-700 mb-1.5 block">الوصف</label>
          <textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            rows={3}
            placeholder="وصف تفصيلي للعقار..."
            className="w-full p-3 rounded-xl border border-slate-200 text-sm resize-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
        </div>

        {/* رفع الصور */}
        <div>
          <label className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1">
            <Image size={16} /> الصور * (حتى {MAX_IMAGES} صورة)
          </label>
          <p className="text-xs text-slate-400 mb-2">تم اختيار {imageFiles.length} من {MAX_IMAGES}</p>
          <div className="flex flex-wrap gap-2">
            {imagePreviews.map((img, i) => (
              <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200">
                <img src={img} className="w-full h-full object-cover" alt={`صورة ${i + 1}`} />
                <button
                  type="button"
                  onClick={() => removeImage(i)}
                  className="absolute top-0.5 right-0.5 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center shadow"
                >
                  <X size={12} />
                </button>
              </div>
            ))}
            {imageFiles.length < MAX_IMAGES && (
              <label className="w-20 h-20 rounded-xl border-2 border-dashed border-slate-300 flex flex-col items-center justify-center cursor-pointer hover:border-primary-400 hover:bg-primary-50 transition-all">
                <Plus size={20} className="text-slate-400" />
                <span className="text-[10px] text-slate-400 mt-0.5">إضافة</span>
                <input type="file" accept="image/*" multiple onChange={handleImageUpload} className="hidden" />
              </label>
            )}
          </div>
        </div>

        {/* رقم التواصل */}
        <div>
          <label className="text-sm font-semibold text-slate-700 mb-1.5 block">رقم التواصل *</label>
          <input
            type="tel"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="05xxxxxxxx"
            className="w-full p-3 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            required
          />
        </div>

        {/* واتساب */}
        <div>
          <label className="text-sm font-semibold text-slate-700 mb-1.5 block">رقم الواتساب</label>
          <input
            type="tel"
            value={form.whatsapp}
            onChange={(e) => setForm({ ...form, whatsapp: e.target.value })}
            placeholder="05xxxxxxxx (اتركه فارغاً لاستخدام رقم التواصل)"
            className="w-full p-3 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
        </div>

        {/* زر النشر */}
        <button
          type="submit"
          disabled={uploading || loading}
          className="w-full py-3.5 bg-primary-600 text-white rounded-xl font-bold text-base hover:bg-primary-700 disabled:opacity-50 shadow-lg shadow-primary-200 transition-all"
        >
          {uploading ? 'جاري نشر العقار...' : '🏠 نشر العقار'}
        </button>
      </form>
    </div>
  )
}