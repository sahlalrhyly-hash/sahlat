import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowRight, Users, Building2, BarChart3, Trash2 } from 'lucide-react'
import { collection, getDocs } from 'firebase/firestore'
import { db } from '@/lib/firebase'
import { useAuthStore } from '@/store/authStore'
import { usePropertyStore } from '@/store/propertyStore'
import { User } from '@/types'

export default function Admin() {
  const navigate = useNavigate()
  const { user } = useAuthStore()
  const { properties, deleteProperty } = usePropertyStore()
  const [users, setUsers] = useState<User[]>([])
  const [loadingUsers, setLoadingUsers] = useState(true)

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const snapshot = await getDocs(collection(db, 'users'))
        const usersData = snapshot.docs.map(d => d.data() as User)
        setUsers(usersData)
      } catch {
        /* ignore */
      } finally {
        setLoadingUsers(false)
      }
    }
    fetchUsers()
  }, [])

  if (!user || user.role !== 'admin') {
    return <div className="p-8 text-center text-slate-400">غير مصرح لك بالوصول</div>
  }

  const stats = [
    { label: 'المستخدمين', value: users.length, icon: Users, color: 'text-blue-600 bg-blue-50' },
    { label: 'العقارات', value: properties.length, icon: Building2, color: 'text-green-600 bg-green-50' },
    { label: 'المشاهدات', value: properties.reduce((s, p) => s + p.views, 0), icon: BarChart3, color: 'text-purple-600 bg-purple-50' },
  ]

  return (
    <div className="pb-4">
      <div className="sticky top-0 z-40 bg-white border-b px-4 h-12 flex items-center gap-3">
        <button onClick={() => navigate(-1)}><ArrowRight size={22} /></button>
        <h2 className="font-bold">لوحة الإدارة</h2>
      </div>

      <div className="p-4 space-y-4">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {stats.map(s => (
            <div key={s.label} className="bg-white rounded-xl p-3 border text-center">
              <div className={`w-10 h-10 rounded-full mx-auto mb-2 flex items-center justify-center ${s.color}`}>
                <s.icon size={18} />
              </div>
              <p className="text-lg font-bold text-slate-800">{s.value}</p>
              <p className="text-[10px] text-slate-500">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Users */}
        <div className="bg-white rounded-xl border">
          <h3 className="font-bold text-sm p-3 border-b">المستخدمين</h3>
          <div className="divide-y">
            {loadingUsers ? (
              <div className="p-4 text-center text-slate-400 text-sm">جاري التحميل...</div>
            ) : users.length === 0 ? (
              <div className="p-4 text-center text-slate-400 text-sm">لا يوجد مستخدمين</div>
            ) : (
              users.map(u => (
                <div key={u.id} className="p-3 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{u.name}</p>
                    <p className="text-xs text-slate-500">{u.email}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${u.role === 'admin' ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-600'}`}>
                    {u.role === 'admin' ? 'مدير' : 'مستخدم'}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Properties Management */}
        <div className="bg-white rounded-xl border">
          <h3 className="font-bold text-sm p-3 border-b">إدارة العقارات</h3>
          <div className="divide-y">
            {properties.length === 0 ? (
              <div className="p-4 text-center text-slate-400 text-sm">لا يوجد عقارات</div>
            ) : (
              properties.map(p => (
                <div key={p.id} className="p-3 flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium line-clamp-1">{p.title}</p>
                    <p className="text-xs text-slate-500">{p.ownerName} • {p.views} مشاهدة</p>
                  </div>
                  <button onClick={() => deleteProperty(p.id)} className="p-2 text-red-500 hover:bg-red-50 rounded">
                    <Trash2 size={16} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}