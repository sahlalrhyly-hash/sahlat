import { useState, useRef, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowRight, Send, Loader2 } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useMessageStore } from '@/store/messageStore'
import { usePropertyStore } from '@/store/propertyStore'

export default function Chat() {
  const { userId, propertyId } = useParams()
  const navigate = useNavigate()
  const { user } = useAuthStore()
  const { messages, subscribeMessages, sendMessage, markAsRead } = useMessageStore()
  const { getPropertyById } = usePropertyStore()
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const property = getPropertyById(propertyId || '')
  const conversationId = user && userId ? [user.id, userId].sort().join('-') + '-' + propertyId : ''

  useEffect(() => {
    if (!conversationId) return
    const unsubscribe = subscribeMessages(conversationId)
    // Mark as read when opening chat
    if (user) {
      markAsRead(conversationId, user.id)
    }
    return () => unsubscribe()
  }, [conversationId])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  const handleSend = async () => {
    if (!text.trim() || !user || !userId || !propertyId || !property) return
    setSending(true)
    try {
      await sendMessage(user.id, userId, propertyId, property.title, text)
      setText('')
    } catch {
      /* ignore */
    } finally {
      setSending(false)
    }
  }

  if (!user) return <div className="p-8 text-center">يرجى تسجيل الدخول</div>

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)]">
      {/* Header */}
      <div className="bg-white border-b px-4 h-12 flex items-center gap-3 shrink-0">
        <button onClick={() => navigate(-1)}><ArrowRight size={22} /></button>
        <div>
          <h3 className="text-sm font-bold line-clamp-1">{property?.title || 'محادثة'}</h3>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && (
          <p className="text-center text-slate-400 text-sm py-8">ابدأ المحادثة...</p>
        )}
        {messages.map(msg => (
          <div key={msg.id} className={`flex ${msg.senderId === user.id ? 'justify-start' : 'justify-end'}`}>
            <div className={`max-w-[75%] px-3 py-2 rounded-xl text-sm ${
              msg.senderId === user.id
                ? 'bg-primary-600 text-white rounded-br-sm'
                : 'bg-slate-100 text-slate-800 rounded-bl-sm'
            }`}>
              {msg.text}
              <div className={`text-[10px] mt-1 ${msg.senderId === user.id ? 'text-white/70' : 'text-slate-400'}`}>
                {new Date(msg.createdAt).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t p-3 flex gap-2 shrink-0">
        <input
          type="text" value={text} onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && !sending && handleSend()}
          placeholder="اكتب رسالة..."
          className="flex-1 p-2.5 rounded-lg border border-slate-200 text-sm"
          disabled={sending}
        />
        <button onClick={handleSend} disabled={sending || !text.trim()}
          className="p-2.5 bg-primary-600 text-white rounded-lg disabled:opacity-50">
          {sending ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
        </button>
      </div>
    </div>
  )
}