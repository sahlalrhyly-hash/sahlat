import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowRight, Plus, X, Upload, Video, Image, Trash2 } from 'lucide-react'
import { usePropertyStore } from '@/store/propertyStore'
import { useAuthStore } from '@/store/authStore'

export default function EditProperty() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { getPropertyById, updateProperty, deleteProperty, loading } = usePropertyStore()
  const { user } = useAuthStore()
  const property = id ? getPropertyById(id) : undefined

  const [form, setForm] = useState({
    title: '', description: '', type: 'apartment' as any, purpose: 'sale' as any,
    price: '', area: '', rooms: '', bathrooms: '',
    city: '', district: '', address: '', features: '',
  })
  const [existingImages, setExistingImages] = useState<string[]>([])
  const [existingVideos, setExistingVideos] = useState<string[]>([])
  const [newImageFiles, setNewImageFiles] = useState<File[]>([])
  const [newImagePreviews, setNewImagePreviews] = useState<string[]>([])
  const [newVideoFiles, setNewVideoFiles] = useState<File[]>([])
  const [newVideoNames, setNewVideoNames] = useState<string[]>([])
  const [error, setError] = useState('')
  const [uploading, setUploading] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  useEffect(() => {
    if (property) {
      setForm({
        title: property.title, description: property.description, type: property.type, purpose: property.purpose,
        price: String(property.price), area: String(property.area), rooms: String(property.rooms), bathrooms: String(property.bathrooms),
        city: property.city, district: property.district, address: property.address,
        features: property.features.join(', '),
      })
      setExistingImages(property.images || [])
      setExistingVideos(property.videos || [])
    }
  }, [property])

  const handleNewImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    const newFiles = Array.from(files)
    setNewImageFiles(prev => [...prev, ...newFiles])
    newFiles.forEach(file => {
      const reader = new FileReader()
      reader.onload = (ev) => {
        if (ev.target?.result) setNewImagePreviews(prev => [...prev, ev.target!.result as string])
      }
      reader.readAsDataURL(file)
    })
  }

  const handleNewVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    const newFiles = Array.from(files)
    setNewVideoFiles(prev => [...prev, ...newFiles])
    setNewVideoNames(prev => [...prev, ...newFiles.map(f => f.name)])
  }

  const removeExistingImage = (index: number) => {
    setExistingImages(existingImages.filter((_, i) => i !== index))
  }

  const removeExistingVideo = (index: number) => {
    setExistingVideos(existingVideos.filter((_, i) => i !== index))
  }

  const removeNewImage = (index: number) => {
    setNewImageFiles(newImageFiles.filter((_, i) => i !== index))
    setNewImagePreviews(newImagePreviews.filter((_, i) => i !== index))
  }

  const removeNewVideo = (index: number) => {
    setNewVideoFiles(newVideoFiles.filter((_, i) => i !== index))
    setNewVideoNames(newVideoNames.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!id || !user) return
    if (!form.title || !form.price || !form.area) { setError('يرجى ملء الحقول المطلوبة'); return }
    if (existingImages.length === 0 && newImageFiles.length === 0) { setError('يرجى إضافة صورة واحدة على الأقل'); return }

    setUploading(true)
    setError('')
    try {
      await updateProperty(id, {
        title: form.title, description: form.description, type: form.type, purpose: form.purpose,
        price: Number(form.price), area: Number(form.area), rooms: Number(form.rooms) || 0, bathrooms: Number(form.bathrooms) || 0,
        city: form.city, district: form.district, address: form.address,
        images: existingImages, videos: existingVideos,
        features: form.features.split(',').map(f => f.trim()).filter(Boolean),
      }, newImageFiles, newVideoFiles)
      navigate(`/property/${id}`)
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء تحديث العقار')
    } finally {
      setUploading(false)
    }
  }

  const handleDelete = async () => {
    if (!id) return
    try {
      await deleteProperty(id)
      navigate('/')
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء حذف العقار')
    }
  }

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-slate-500">العقار غير موجود</p>
      </div>
    )
  }

  if (user?.id !== property.ownerId && user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-red-500">ليس لديك صلاحية لتعديل هذا العقار</p>
      </div>
    )
  }

  return (
    <div className="pb-4">
      <div className="sticky top-0 z-40 bg-white border-b px-4 h-12 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)}><ArrowRight size={22} /></button>
          <h2 className="font-bold">تعديل العقار</h2>
        </div>
        <button onClick={() => setShowDeleteConfirm(true)} className="text-red-500 p-2">
          <Trash2 size={20} />
        </button>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full space-y-4">
            <h3 className="font-bold text-lg">حذف العقار</h3>
            <p className="text-slate-600">هل أنت متأكد من حذف هذا العقار؟ لا يمكن التراجع عن هذا الإجراء.</p>
            <div className="flex gap-3">
              <button onClick={handleDelete} className="flex-1 py-2 bg-red-600 text-white rounded-lg font-medium">حذف</button>
              <button onClick={() => setShowDeleteConfirm(false)} className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="p-4 space-y-4">
        {error && <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg">{error}</div>}

        {uploading && (
          <div className="bg-blue-50 text-blue-600 text-sm p-3 rounded-lg flex items-center gap-2">
            <Upload size={16} className="animate-bounce" />
            جاري رفع الملفات... يرجى الانتظار
          </div>
        )}

        {/* Existing Images */}
        <div>
          <label className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-1">
            <Image size={16} /> الصور الحالية
          </label>
          <div className="flex flex-wrap gap-2">
            {existingImages.map((img, i) => (
              <div key={i} className="relative w-20 h-20 rounded-lg overflow-hidden">
                <img src={img} className="w-full h-full object-cover" />
                <button type="button" onClick={() => removeExistingImage(i)}
                  className="absolute top-0.5 right-0.5 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center">
                  <X size={12} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* New Images */}
        <div>
          <label className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-1">
            <Plus size={16} /> إضافة صور جديدة
          </label>
          <div className="flex flex-wrap gap-2">
            {newImagePreviews.map((img, i) => (
              <div key={i} className="relative w-20 h-20 rounded-lg overflow-hidden border-2 border-green-300">
                <img src={img} className="w-full h-full object-cover" />
                <button type="button" onClick={() => removeNewImage(i)}
                  className="absolute top-0.5 right-0.5 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center">
                  <X size={12} />
                </button>
              </div>
            ))}
            <label className="w-20 h-20 rounded-lg border-2 border-dashed border-green-300 flex items-center justify-center cursor-pointer hover:border-green-500">
              <Plus size={24} className="text-green-400" />
              <input type="file" accept="image/*" multiple onChange={handleNewImageUpload} className="hidden" />
            </label>
          </div>
        </div>

        {/* Existing Videos */}
        {existingVideos.length > 0 && (
          <div>
            <label className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-1">
              <Video size={16} /> الفيديوهات الحالية
            </label>
            <div className="space-y-2">
              {existingVideos.map((url, i) => (
                <div key={i} className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Video size={16} className="text-slate-500" />
                  <span className="text-sm text-slate-600 flex-1 truncate">فيديو {i + 1}</span>
                  <button type="button" onClick={() => removeExistingVideo(i)} className="text-red-500">
                    <X size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* New Videos */}
        <div>
          <label className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-1">
            <Video size={16} /> إضافة فيديوهات جديدة
          </label>
          <div className="space-y-2">
            {newVideoNames.map((name, i) => (
              <div key={i} className="flex items-center gap-2 bg-green-50 p-2 rounded-lg">
                <Video size={16} className="text-green-500" />
                <span className="text-sm text-green-700 flex-1 truncate">{name}</span>
                <button type="button" onClick={() => removeNewVideo(i)} className="text-red-500">
                  <X size={16} />
                </button>
              </div>
            ))}
            <label className="flex items-center gap-2 p-3 rounded-lg border-2 border-dashed border-slate-300 cursor-pointer hover:border-primary-400">
              <Plus size={18} className="text-slate-400" />
              <span className="text-sm text-slate-400">إضافة فيديو</span>
              <input type="file" accept="video/*" multiple onChange={handleNewVideoUpload} className="hidden" />
            </label>
          </div>
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700 mb-1 block">العنوان *</label>
          <input type="text" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full p-3 rounded-lg border border-slate-200 text-sm" required />
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700 mb-1 block">الوصف</label>
          <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
            rows={3} className="w-full p-3 rounded-lg border border-slate-200 text-sm resize-none" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium text-slate-700 mb-1 block">النوع</label>
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}
              className="w-full p-3 rounded-lg border border-slate-200 text-sm">
              <option value="apartment">شقة</option>
              <option value="villa">فيلا</option>
              <option value="land">أرض</option>
              <option value="office">مكتب</option>
              <option value="shop">محل</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium text-slate-700 mb-1 block">الغرض</label>
            <select value={form.purpose} onChange={(e) => setForm({ ...form, purpose: e.target.value })}
              className="w-full p-3 rounded-lg border border-slate-200 text-sm">
              <option value="sale">للبيع</option>
              <option value="rent">للإيجار</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium text-slate-700 mb-1 block">السعر (ريال) *</label>
            <input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })}
              className="w-full p-3 rounded-lg border border-slate-200 text-sm" required />
          </div>
          <div>
            <label className="text-sm font-medium text-slate-700 mb-1 block">المساحة (م²) *</label>
            <input type="number" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })}
              className="w-full p-3 rounded-lg border border-slate-200 text-sm" required />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium text-slate-700 mb-1 block">الغرف</label>
            <input type="number" value={form.rooms} onChange={(e) => setForm({ ...form, rooms: e.target.value })}
              className="w-full p-3 rounded-lg border border-slate-200 text-sm" />
          </div>
          <div>
            <label className="text-sm font-medium text-slate-700 mb-1 block">الحمامات</label>
            <input type="number" value={form.bathrooms} onChange={(e) => setForm({ ...form, bathrooms: e.target.value })}
              className="w-full p-3 rounded-lg border border-slate-200 text-sm" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium text-slate-700 mb-1 block">المدينة</label>
            <input type="text" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })}
              className="w-full p-3 rounded-lg border border-slate-200 text-sm" />
          </div>
          <div>
            <label className="text-sm font-medium text-slate-700 mb-1 block">الحي</label>
            <input type="text" value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })}
              className="w-full p-3 rounded-lg border border-slate-200 text-sm" />
          </div>
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700 mb-1 block">المميزات (مفصولة بفاصلة)</label>
          <input type="text" value={form.features} onChange={(e) => setForm({ ...form, features: e.target.value })}
            className="w-full p-3 rounded-lg border border-slate-200 text-sm" />
        </div>

        <button type="submit" disabled={uploading || loading}
          className="w-full py-3 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 disabled:opacity-50">
          {uploading ? 'جاري التحديث...' : 'حفظ التعديلات'}
        </button>
      </form>
    </div>
  )
}