import { Heart } from 'lucide-react'
import PropertyCard from '@/components/PropertyCard'
import { usePropertyStore } from '@/store/propertyStore'

export default function Favorites() {
  const { properties, favorites } = usePropertyStore()
  const favoriteProperties = properties.filter(p => favorites.includes(p.id))

  return (
    <div className="p-4">
      <h2 className="text-lg font-bold text-slate-800 mb-4">المفضلة</h2>
      {favoriteProperties.length > 0 ? (
        <div className="space-y-4">
          {favoriteProperties.map(p => <PropertyCard key={p.id} property={p} />)}
        </div>
      ) : (
        <div className="text-center py-16 text-slate-400">
          <Heart size={48} className="mx-auto mb-3 text-slate-200" />
          <p className="text-lg">لا توجد عقارات مفضلة</p>
          <p className="text-sm mt-1">اضغط على القلب لإضافة عقار للمفضلة</p>
        </div>
      )}
    </div>
  )
}