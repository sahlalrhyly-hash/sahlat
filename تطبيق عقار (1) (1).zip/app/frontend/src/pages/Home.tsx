import { useState } from 'react'
import { Search, SlidersHorizontal, Loader2 } from 'lucide-react'
import PropertyCard from '@/components/PropertyCard'
import { usePropertyStore } from '@/store/propertyStore'

export default function Home() {
  const { searchProperties, loading } = usePropertyStore()
  const [query, setQuery] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [filters, setFilters] = useState<any>({})

  const properties = searchProperties(query, filters)

  const typeOptions = [
    { value: '', label: 'الكل' },
    { value: 'apartment', label: 'شقة' },
    { value: 'villa', label: 'فيلا' },
    { value: 'land', label: 'أرض' },
    { value: 'building', label: 'عمارة' },
    { value: 'farm', label: 'مزرعة' },
    { value: 'office', label: 'مكتب' },
    { value: 'shop', label: 'محل' },
  ]

  const purposeOptions = [
    { value: '', label: 'الكل' },
    { value: 'sale', label: 'للبيع' },
    { value: 'rent', label: 'للإيجار' },
  ]

  return (
    <div className="p-4 pb-24">
      {/* Search Bar */}
      <div className="flex gap-2 mb-4">
        <div className="flex-1 relative">
          <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="ابحث عن عقار..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pr-10 pl-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`p-2.5 rounded-xl border ${showFilters ? 'bg-primary-600 text-white border-primary-600' : 'bg-white border-slate-200 text-slate-600'}`}
        >
          <SlidersHorizontal size={20} />
        </button>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="bg-white rounded-xl p-4 mb-4 border border-slate-200 space-y-3 shadow-sm">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 mb-1 block">النوع</label>
              <select
                value={filters.type || ''}
                onChange={(e) => setFilters({ ...filters, type: e.target.value || undefined })}
                className="w-full p-2 rounded-lg border border-slate-200 text-sm"
              >
                {typeOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500 mb-1 block">الغرض</label>
              <select
                value={filters.purpose || ''}
                onChange={(e) => setFilters({ ...filters, purpose: e.target.value || undefined })}
                className="w-full p-2 rounded-lg border border-slate-200 text-sm"
              >
                {purposeOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 mb-1 block">الحد الأدنى للسعر</label>
              <input
                type="number"
                placeholder="0"
                onChange={(e) => setFilters({ ...filters, minPrice: e.target.value ? Number(e.target.value) : undefined })}
                className="w-full p-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="text-xs text-slate-500 mb-1 block">الحد الأعلى للسعر</label>
              <input
                type="number"
                placeholder="0"
                onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value ? Number(e.target.value) : undefined })}
                className="w-full p-2 rounded-lg border border-slate-200 text-sm"
              />
            </div>
          </div>
          <button
            onClick={() => { setFilters({}); setQuery('') }}
            className="w-full py-2 text-sm text-primary-600 border border-primary-200 rounded-lg hover:bg-primary-50"
          >
            مسح الفلاتر
          </button>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 size={32} className="animate-spin text-primary-600" />
        </div>
      )}

      {/* Properties Grid */}
      {!loading && (
        <div className="space-y-4">
          {properties.length > 0 ? (
            properties.map(p => <PropertyCard key={p.id} property={p} />)
          ) : (
            <div className="text-center py-12 text-slate-400">
              <p className="text-lg">لا توجد عقارات</p>
              <p className="text-sm mt-1">أضف عقارك الأول من الزر أدناه</p>
            </div>
          )}
        </div>
      )}


    </div>
  )
}