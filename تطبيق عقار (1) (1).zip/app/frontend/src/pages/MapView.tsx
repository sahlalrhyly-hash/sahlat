import { useNavigate } from 'react-router-dom'
import { ArrowRight, MapPin } from 'lucide-react'
import { usePropertyStore } from '@/store/propertyStore'
import { formatPrice } from '@/lib/utils'
import { Link } from 'react-router-dom'

export default function MapView() {
  const navigate = useNavigate()
  const { properties } = usePropertyStore()
  const activeProperties = properties.filter(p => p.status === 'active')

  return (
    <div className="pb-4">
      <div className="sticky top-0 z-40 bg-white border-b px-4 h-12 flex items-center gap-3">
        <button onClick={() => navigate(-1)}><ArrowRight size={22} /></button>
        <h2 className="font-bold">خريطة العقارات</h2>
      </div>

      {/* Map Placeholder with property pins */}
      <div className="relative h-64 bg-gradient-to-b from-green-100 to-green-50 border-b flex items-center justify-center">
        <div className="text-center">
          <MapPin size={48} className="mx-auto text-primary-600 mb-2" />
          <p className="text-sm text-slate-600">خريطة تفاعلية</p>
          <p className="text-xs text-slate-400">{activeProperties.length} عقار متاح</p>
        </div>
        {/* Simulated pins */}
        {activeProperties.slice(0, 4).map((p, i) => (
          <div key={p.id} className="absolute" style={{ top: `${20 + i * 15}%`, left: `${15 + i * 20}%` }}>
            <div className="bg-primary-600 text-white text-[10px] px-1.5 py-0.5 rounded-full whitespace-nowrap">
              {formatPrice(p.price)}
            </div>
          </div>
        ))}
      </div>

      {/* Property List */}
      <div className="p-4 space-y-3">
        <h3 className="font-bold text-slate-700 text-sm">العقارات القريبة</h3>
        {activeProperties.map(p => (
          <Link key={p.id} to={`/property/${p.id}`}
            className="flex gap-3 bg-white rounded-lg p-3 border border-slate-100 hover:border-primary-200">
            <img src={p.images[0]} className="w-16 h-16 rounded-lg object-cover" />
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-medium line-clamp-1">{p.title}</h4>
              <p className="text-xs text-slate-500 flex items-center gap-1"><MapPin size={10} /> {p.district}</p>
              <p className="text-sm font-bold text-primary-600 mt-1">{formatPrice(p.price)}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}