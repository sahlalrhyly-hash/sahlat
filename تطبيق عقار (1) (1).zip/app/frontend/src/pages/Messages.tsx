import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { MessageCircle, Loader2 } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useMessageStore } from '@/store/messageStore'

export default function Messages() {
  const { user } = useAuthStore()
  const { conversations, subscribeConversations } = useMessageStore()

  useEffect(() => {
    if (!user) return
    const unsubscribe = subscribeConversations(user.id)
    return () => unsubscribe()
  }, [user?.id])

  if (!user) return <div className="p-8 text-center text-slate-400">يرجى تسجيل الدخول</div>

  const userConversations = conversations.filter(c => c.participants.includes(user.id))

  return (
    <div className="p-4">
      <h2 className="text-lg font-bold text-slate-800 mb-4">الرسائل</h2>
      {userConversations.length > 0 ? (
        <div className="space-y-2">
          {userConversations.map(conv => {
            const otherUserId = conv.participants.find(p => p !== user.id) || ''
            return (
              <Link key={conv.id} to={`/chat/${otherUserId}/${conv.propertyId}`}
                className="block bg-white rounded-lg p-3 border border-slate-100 hover:border-primary-200">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-sm text-slate-800 line-clamp-1">{conv.propertyTitle}</h3>
                  {conv.unreadCount > 0 && (
                    <span className="bg-primary-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">{conv.unreadCount}</span>
                  )}
                </div>
                <p className="text-xs text-slate-500 mt-1 line-clamp-1">{conv.lastMessage}</p>
                <p className="text-[10px] text-slate-400 mt-1">
                  {new Date(conv.lastMessageAt).toLocaleDateString('ar-SA')}
                </p>
              </Link>
            )
          })}
        </div>
      ) : (
        <div className="text-center py-16 text-slate-400">
          <MessageCircle size={48} className="mx-auto mb-3 text-slate-200" />
          <p className="text-lg">لا توجد محادثات</p>
          <p className="text-sm mt-1">تواصل مع المعلنين من صفحة العقار</p>
        </div>
      )}
    </div>
  )
}