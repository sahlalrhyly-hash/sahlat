import { useEffect } from 'react'
import { Bell, Check } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useNotificationStore } from '@/store/notificationStore'
import { formatDate } from '@/lib/utils'

export default function Notifications() {
  const { user } = useAuthStore()
  const { notifications, subscribeNotifications, markAsRead, markAllAsRead } = useNotificationStore()

  useEffect(() => {
    if (!user) return
    const unsubscribe = subscribeNotifications(user.id)
    return () => unsubscribe()
  }, [user?.id])

  if (!user) return <div className="p-8 text-center text-slate-400">يرجى تسجيل الدخول</div>

  const userNotifications = notifications.filter(n => n.userId === user.id)

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-slate-800">الإشعارات</h2>
        {userNotifications.some(n => !n.read) && (
          <button onClick={() => markAllAsRead(user.id)} className="text-xs text-primary-600 flex items-center gap-1">
            <Check size={14} /> قراءة الكل
          </button>
        )}
      </div>

      {userNotifications.length > 0 ? (
        <div className="space-y-2">
          {userNotifications.map(n => (
            <div key={n.id} onClick={() => !n.read && markAsRead(n.id)}
              className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                n.read ? 'bg-white border-slate-100' : 'bg-primary-50 border-primary-100'
              }`}>
              <div className="flex items-start justify-between">
                <h3 className="font-medium text-sm text-slate-800">{n.title}</h3>
                {!n.read && <span className="w-2 h-2 rounded-full bg-primary-600 mt-1.5" />}
              </div>
              <p className="text-xs text-slate-500 mt-1">{n.body}</p>
              <p className="text-[10px] text-slate-400 mt-1">{formatDate(n.createdAt)}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 text-slate-400">
          <Bell size={48} className="mx-auto mb-3 text-slate-200" />
          <p>لا توجد إشعارات</p>
        </div>
      )}
    </div>
  )
}