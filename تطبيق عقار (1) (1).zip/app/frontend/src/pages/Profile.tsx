import { Link, useNavigate } from 'react-router-dom'
import { User, Settings, LogOut, Building2, Edit } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { usePropertyStore } from '@/store/propertyStore'

export default function Profile() {
  const navigate = useNavigate()
  const { user, isAuthenticated, logout } = useAuthStore()
  const { getUserProperties, deleteProperty } = usePropertyStore()

  if (!isAuthenticated || !user) {
    return (
      <div className="p-4 text-center py-16">
        <User size={48} className="mx-auto mb-3 text-slate-200" />
        <p className="text-slate-500 mb-4">يرجى تسجيل الدخول لعرض ملفك الشخصي</p>
        <Link to="/login" className="inline-block px-6 py-2 bg-primary-600 text-white rounded-lg">تسجيل الدخول</Link>
      </div>
    )
  }

  const myProperties = getUserProperties(user.id)

  const handleLogout = async () => {
    await logout()
    navigate('/login')
  }

  return (
    <div className="p-4 space-y-4">
      {/* Profile Card */}
      <div className="bg-white rounded-xl p-4 border flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center">
          <User size={28} className="text-primary-600" />
        </div>
        <div className="flex-1">
          <h2 className="font-bold text-slate-800">{user.name}</h2>
          <p className="text-sm text-slate-500">{user.email}</p>
          <p className="text-sm text-slate-500">{user.phone}</p>
        </div>
      </div>

      {/* Actions */}
      <div className="bg-white rounded-xl border divide-y">
        {user.role === 'admin' && (
          <Link to="/admin" className="flex items-center gap-3 p-3 hover:bg-slate-50">
            <Settings size={20} className="text-slate-500" />
            <span className="text-sm">لوحة الإدارة</span>
          </Link>
        )}
        <Link to="/settings" className="flex items-center gap-3 p-3 hover:bg-slate-50">
          <Settings size={20} className="text-slate-500" />
          <span className="text-sm">الإعدادات</span>
        </Link>
        <button onClick={handleLogout} className="flex items-center gap-3 p-3 hover:bg-slate-50 w-full text-right">
          <LogOut size={20} className="text-red-500" />
          <span className="text-sm text-red-500">تسجيل الخروج</span>
        </button>
      </div>

      {/* My Properties */}
      <div>
        <h3 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
          <Building2 size={18} /> عقاراتي ({myProperties.length})
        </h3>
        {myProperties.length > 0 ? (
          <div className="space-y-2">
            {myProperties.map(p => (
              <div key={p.id} className="bg-white rounded-lg p-3 border flex items-center gap-3">
                <img src={p.images[0]} className="w-16 h-16 rounded-lg object-cover" />
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium line-clamp-1">{p.title}</h4>
                  <p className="text-xs text-slate-500">{p.city} - {p.district}</p>
                </div>
                <div className="flex gap-1">
                  <Link to={`/edit/${p.id}`} className="p-2 text-primary-600 hover:bg-primary-50 rounded">
                    <Edit size={16} />
                  </Link>
                  <button onClick={() => deleteProperty(p.id)} className="p-2 text-red-500 hover:bg-red-50 rounded text-xs">
                    حذف
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-slate-400 text-sm py-4">لم تضف عقارات بعد</p>
        )}
      </div>
    </div>
  )
}