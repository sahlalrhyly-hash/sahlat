import { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { ArrowRight, Heart, Share2, Phone, MessageCircle, MapPin, BedDouble, Bath, Maximize, Eye, Calendar, Edit, Trash2 } from 'lucide-react'
import { usePropertyStore } from '@/store/propertyStore'
import { useAuthStore } from '@/store/authStore'
import { useMessageStore } from '@/store/messageStore'
import { formatPrice, formatDate } from '@/lib/utils'

export default function PropertyDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { getPropertyById, favorites, toggleFavorite, incrementViews, deleteProperty } = usePropertyStore()
  const { user, isAuthenticated } = useAuthStore()
  const { sendMessage } = useMessageStore()
  const [currentImage, setCurrentImage] = useState(0)
  const [msgText, setMsgText] = useState('')
  const [msgSent, setMsgSent] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  const property = getPropertyById(id || '')

  useEffect(() => {
    if (id) incrementViews(id)
  }, [id])

  if (!property) return <div className="p-8 text-center text-slate-400">العقار غير موجود</div>

  const isFavorite = favorites.includes(property.id)
  const isOwner = user?.id === property.ownerId
  const isAdmin = user?.role === 'admin'

  const typeLabels: Record<string, string> = { apartment: 'شقة', villa: 'فيلا', land: 'أرض', office: 'مكتب', shop: 'محل' }
  const purposeLabels: Record<string, string> = { sale: 'للبيع', rent: 'للإيجار' }

  const handleSendMessage = () => {
    if (!msgText.trim() || !user) return
    sendMessage(user.id, property.ownerId, property.id, property.title, msgText)
    setMsgText('')
    setMsgSent(true)
    setTimeout(() => setMsgSent(false), 3000)
  }

  const handleDelete = async () => {
    try {
      await deleteProperty(property.id)
      navigate('/')
    } catch { /* ignore */ }
  }

  return (
    <div className="pb-4">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white/90 backdrop-blur-sm border-b px-4 h-12 flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="p-1"><ArrowRight size={22} /></button>
        <div className="flex gap-2">
          {(isOwner || isAdmin) && (
            <>
              <Link to={`/edit/${property.id}`} className="p-1">
                <Edit size={20} className="text-primary-600" />
              </Link>
              <button onClick={() => setShowDeleteConfirm(true)} className="p-1">
                <Trash2 size={20} className="text-red-500" />
              </button>
            </>
          )}
          <button onClick={() => toggleFavorite(property.id)} className="p-1">
            <Heart size={22} className={isFavorite ? 'fill-red-500 text-red-500' : 'text-slate-400'} />
          </button>
          <button onClick={() => navigator.clipboard.writeText(window.location.href)} className="p-1">
            <Share2 size={22} className="text-slate-400" />
          </button>
        </div>
      </div>

      {/* Delete Confirm */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full space-y-4">
            <h3 className="font-bold text-lg">حذف العقار</h3>
            <p className="text-slate-600">هل أنت متأكد من حذف هذا العقار؟ لا يمكن التراجع عن هذا الإجراء.</p>
            <div className="flex gap-3">
              <button onClick={handleDelete} className="flex-1 py-2 bg-red-600 text-white rounded-lg font-medium">حذف</button>
              <button onClick={() => setShowDeleteConfirm(false)} className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* Image Gallery */}
      <div className="relative h-64 bg-slate-200">
        <img src={property.images[currentImage]} alt="" className="w-full h-full object-cover" />
        {property.images.length > 1 && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {property.images.map((_, i) => (
              <button key={i} onClick={() => setCurrentImage(i)}
                className={`w-2 h-2 rounded-full ${i === currentImage ? 'bg-white' : 'bg-white/50'}`} />
            ))}
          </div>
        )}
        <div className="absolute top-3 right-3 flex gap-2">
          <span className="bg-primary-600 text-white text-xs px-2 py-1 rounded-full">{typeLabels[property.type]}</span>
          <span className="bg-green-600 text-white text-xs px-2 py-1 rounded-full">{purposeLabels[property.purpose]}</span>
        </div>
        <div className="absolute bottom-3 right-3 bg-black/60 text-white text-xs px-2 py-1 rounded">
          {currentImage + 1} / {property.images.length}
        </div>
      </div>

      {/* Image Thumbnails */}
      {property.images.length > 1 && (
        <div className="flex gap-2 p-3 overflow-x-auto">
          {property.images.map((img, i) => (
            <button key={i} onClick={() => setCurrentImage(i)}
              className={`w-16 h-12 rounded-lg overflow-hidden flex-shrink-0 border-2 ${i === currentImage ? 'border-primary-500' : 'border-transparent'}`}>
              <img src={img} className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      )}

      {/* Videos */}
      {property.videos && property.videos.length > 0 && (
        <div className="p-4 border-t">
          <h3 className="font-bold text-slate-700 mb-2">الفيديوهات ({property.videos.length})</h3>
          <div className="space-y-3">
            {property.videos.map((video, i) => (
              <video key={i} controls className="w-full rounded-lg max-h-48" preload="metadata">
                <source src={video} />
              </video>
            ))}
          </div>
        </div>
      )}

      {/* Details */}
      <div className="p-4 space-y-4">
        <div>
          <h1 className="text-xl font-bold text-slate-800">{property.title}</h1>
          <div className="flex items-center gap-1 mt-1 text-slate-500 text-sm">
            <MapPin size={14} /> <span>{property.district}، {property.city}</span>
          </div>
        </div>

        <div className="text-2xl font-bold text-primary-600">
          {formatPrice(property.price)}
          {property.purpose === 'rent' && <span className="text-sm text-slate-400 mr-1">/شهرياً</span>}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {property.rooms > 0 && (
            <div className="bg-slate-50 rounded-lg p-3 text-center">
              <BedDouble size={20} className="mx-auto text-primary-500 mb-1" />
              <p className="text-sm font-medium">{property.rooms} غرف</p>
            </div>
          )}
          {property.bathrooms > 0 && (
            <div className="bg-slate-50 rounded-lg p-3 text-center">
              <Bath size={20} className="mx-auto text-primary-500 mb-1" />
              <p className="text-sm font-medium">{property.bathrooms} حمام</p>
            </div>
          )}
          <div className="bg-slate-50 rounded-lg p-3 text-center">
            <Maximize size={20} className="mx-auto text-primary-500 mb-1" />
            <p className="text-sm font-medium">{property.area} م²</p>
          </div>
        </div>

        {/* Description */}
        <div>
          <h3 className="font-bold text-slate-700 mb-2">الوصف</h3>
          <p className="text-slate-600 text-sm leading-relaxed">{property.description}</p>
        </div>

        {/* Features */}
        {property.features.length > 0 && (
          <div>
            <h3 className="font-bold text-slate-700 mb-2">المميزات</h3>
            <div className="flex flex-wrap gap-2">
              {property.features.map((f, i) => (
                <span key={i} className="bg-primary-50 text-primary-700 text-xs px-3 py-1.5 rounded-full">{f}</span>
              ))}
            </div>
          </div>
        )}

        {/* Meta */}
        <div className="flex items-center gap-4 text-xs text-slate-400 pt-2 border-t">
          <span className="flex items-center gap-1"><Eye size={12} /> {property.views} مشاهدة</span>
          <span className="flex items-center gap-1"><Calendar size={12} /> {formatDate(property.createdAt)}</span>
        </div>

        {/* Owner Actions */}
        {isOwner && (
          <div className="pt-3 border-t">
            <Link to={`/edit/${property.id}`}
              className="w-full py-3 bg-primary-600 text-white rounded-lg font-medium flex items-center justify-center gap-2 text-sm">
              <Edit size={16} /> تعديل العقار
            </Link>
          </div>
        )}

        {/* Contact / Message */}
        {!isOwner && isAuthenticated && (
          <div className="space-y-3 pt-3 border-t">
            <div className="flex gap-2">
              <a href={`tel:${property.ownerPhone}`}
                className="flex-1 py-2.5 bg-green-600 text-white rounded-lg font-medium flex items-center justify-center gap-2 text-sm">
                <Phone size={16} /> اتصال
              </a>
              <Link to={`/chat/${property.ownerId}/${property.id}`}
                className="flex-1 py-2.5 bg-primary-600 text-white rounded-lg font-medium flex items-center justify-center gap-2 text-sm">
                <MessageCircle size={16} /> محادثة
              </Link>
            </div>
            <div className="flex gap-2">
              <input
                type="text" value={msgText} onChange={(e) => setMsgText(e.target.value)}
                placeholder="اكتب رسالة سريعة..."
                className="flex-1 p-2.5 rounded-lg border border-slate-200 text-sm"
              />
              <button onClick={handleSendMessage} className="px-4 bg-primary-600 text-white rounded-lg text-sm">إرسال</button>
            </div>
            {msgSent && <p className="text-green-600 text-xs">✓ تم إرسال الرسالة</p>}
          </div>
        )}
        {!isAuthenticated && (
          <Link to="/login" className="block w-full py-3 bg-primary-600 text-white rounded-lg font-medium text-center text-sm">
            سجل دخول للتواصل مع المعلن
          </Link>
        )}
      </div>
    </div>
  )
}