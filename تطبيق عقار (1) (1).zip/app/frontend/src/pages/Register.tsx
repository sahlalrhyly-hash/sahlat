import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { UserPlus } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'

export default function Register() {
  const navigate = useNavigate()
  const { register, loading } = useAuthStore()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (password.length < 6) {
      setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل')
      return
    }
    const result = await register(name, email, phone, password)
    if (result.success) {
      navigate('/')
    } else {
      setError(result.error || 'حدث خطأ')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-b from-primary-50 to-white">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary-600 mb-2">عقار</h1>
          <p className="text-slate-500">إنشاء حساب جديد</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 shadow-sm border space-y-4">
          {error && (
            <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg">{error}</div>
          )}

          <div>
            <label className="text-sm text-slate-600 mb-1 block">الاسم الكامل</label>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="محمد أحمد"
              className="w-full p-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" required />
          </div>

          <div>
            <label className="text-sm text-slate-600 mb-1 block">البريد الإلكتروني</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="example@email.com"
              className="w-full p-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" required />
          </div>

          <div>
            <label className="text-sm text-slate-600 mb-1 block">رقم الجوال</label>
            <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="05xxxxxxxx"
              className="w-full p-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" required />
          </div>

          <div>
            <label className="text-sm text-slate-600 mb-1 block">كلمة المرور (6 أحرف على الأقل)</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"
              className="w-full p-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" required />
          </div>

          <button type="submit" disabled={loading}
            className="w-full py-3 bg-primary-600 text-white rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-primary-700 disabled:opacity-50">
            <UserPlus size={18} />
            {loading ? 'جاري التسجيل...' : 'إنشاء حساب'}
          </button>

          <p className="text-center text-sm text-slate-500">
            لديك حساب؟ <Link to="/login" className="text-primary-600 font-medium">تسجيل الدخول</Link>
          </p>
        </form>
      </div>
    </div>
  )
}