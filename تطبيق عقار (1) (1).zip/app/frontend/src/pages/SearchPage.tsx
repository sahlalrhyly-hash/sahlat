import { useState } from 'react'
import { Search, MapPin } from 'lucide-react'
import PropertyCard from '@/components/PropertyCard'
import { usePropertyStore } from '@/store/propertyStore'
import { Link } from 'react-router-dom'

export default function SearchPage() {
  const { searchProperties } = usePropertyStore()
  const [query, setQuery] = useState('')
  const [filters, setFilters] = useState<any>({})

  const results = searchProperties(query, filters)

  const cities = ['الرياض', 'جدة', 'مكة', 'المدينة', 'الدمام']

  return (
    <div className="p-4">
      <div className="relative mb-4">
        <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input type="text" value={query} onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث بالمدينة، الحي، أو اسم العقار..."
          className="w-full pr-10 pl-4 py-3 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" />
      </div>

      {/* Quick City Filters */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        <button onClick={() => setFilters({ ...filters, city: undefined })}
          className={`shrink-0 px-3 py-1.5 rounded-full text-xs border ${!filters.city ? 'bg-primary-600 text-white border-primary-600' : 'bg-white border-slate-200'}`}>
          الكل
        </button>
        {cities.map(city => (
          <button key={city} onClick={() => setFilters({ ...filters, city })}
            className={`shrink-0 px-3 py-1.5 rounded-full text-xs border ${filters.city === city ? 'bg-primary-600 text-white border-primary-600' : 'bg-white border-slate-200'}`}>
            {city}
          </button>
        ))}
      </div>

      {/* Map Link */}
      <Link to="/map" className="flex items-center gap-2 bg-white rounded-lg p-3 border border-slate-200 mb-4 hover:border-primary-300">
        <MapPin size={18} className="text-primary-600" />
        <span className="text-sm text-slate-700">عرض على الخريطة</span>
      </Link>

      {/* Results */}
      <p className="text-xs text-slate-500 mb-3">{results.length} نتيجة</p>
      <div className="space-y-4">
        {results.map(p => <PropertyCard key={p.id} property={p} />)}
      </div>
    </div>
  )
}