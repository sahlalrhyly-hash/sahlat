import { useNavigate } from 'react-router-dom'
import { ArrowRight, Globe, Moon, Bell, Shield } from 'lucide-react'

export default function Settings() {
  const navigate = useNavigate()

  return (
    <div className="pb-4">
      <div className="sticky top-0 z-40 bg-white border-b px-4 h-12 flex items-center gap-3">
        <button onClick={() => navigate(-1)}><ArrowRight size={22} /></button>
        <h2 className="font-bold">الإعدادات</h2>
      </div>

      <div className="p-4 space-y-3">
        <div className="bg-white rounded-xl border divide-y">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <Globe size={20} className="text-slate-500" />
              <span className="text-sm">اللغة</span>
            </div>
            <span className="text-xs text-slate-400">العربية</span>
          </div>
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <Moon size={20} className="text-slate-500" />
              <span className="text-sm">الوضع الداكن</span>
            </div>
            <span className="text-xs text-slate-400">قريباً</span>
          </div>
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <Bell size={20} className="text-slate-500" />
              <span className="text-sm">الإشعارات</span>
            </div>
            <span className="text-xs text-green-600">مفعّلة</span>
          </div>
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <Shield size={20} className="text-slate-500" />
              <span className="text-sm">الخصوصية والأمان</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border p-4">
          <h3 className="font-medium text-sm text-slate-700 mb-2">عن التطبيق</h3>
          <p className="text-xs text-slate-500">عقار - منصة العقارات الشاملة</p>
          <p className="text-xs text-slate-400 mt-1">الإصدار 1.0.0</p>
        </div>
      </div>
    </div>
  )
}