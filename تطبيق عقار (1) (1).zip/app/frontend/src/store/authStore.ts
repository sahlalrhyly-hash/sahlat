import { create } from 'zustand'
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  type User as FirebaseUser,
} from 'firebase/auth'
import { doc, setDoc, getDoc, updateDoc } from 'firebase/firestore'
import { auth, db, isFirebaseConfigured } from '@/lib/firebase'
import { User } from '@/types'

interface AuthState {
  user: User | null
  firebaseUser: FirebaseUser | null
  isAuthenticated: boolean
  loading: boolean
  initialized: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  register: (name: string, email: string, phone: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => Promise<void>
  updateUserProfile: (data: Partial<User>) => Promise<void>
  initAuth: () => void
}

export const useAuthStore = create<AuthState>()((set, get) => ({
  user: null,
  firebaseUser: null,
  isAuthenticated: false,
  loading: false,
  initialized: false,

  initAuth: () => {
    if (!isFirebaseConfigured) {
      // Demo mode - no Firebase configured
      set({ initialized: true, loading: false })
      return
    }
    onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid))
          if (userDoc.exists()) {
            const userData = userDoc.data() as User
            set({ user: userData, firebaseUser, isAuthenticated: true, initialized: true, loading: false })
          } else {
            const userData: User = {
              id: firebaseUser.uid,
              name: firebaseUser.displayName || 'مستخدم',
              email: firebaseUser.email || '',
              phone: '',
              role: 'user',
              createdAt: new Date().toISOString(),
            }
            await setDoc(doc(db, 'users', firebaseUser.uid), userData)
            set({ user: userData, firebaseUser, isAuthenticated: true, initialized: true, loading: false })
          }
        } catch {
          set({ user: null, firebaseUser: null, isAuthenticated: false, initialized: true, loading: false })
        }
      } else {
        set({ user: null, firebaseUser: null, isAuthenticated: false, initialized: true, loading: false })
      }
    })
  },

  login: async (email, password) => {
    if (!isFirebaseConfigured) {
      return { success: false, error: 'Firebase غير مهيأ. يرجى إضافة مفاتيح Firebase في ملف .env' }
    }
    set({ loading: true })
    try {
      const cred = await signInWithEmailAndPassword(auth, email, password)
      const userDoc = await getDoc(doc(db, 'users', cred.user.uid))
      if (userDoc.exists()) {
        const userData = userDoc.data() as User
        set({ user: userData, firebaseUser: cred.user, isAuthenticated: true, loading: false })
      }
      return { success: true }
    } catch (err: any) {
      set({ loading: false })
      let error = 'حدث خطأ في تسجيل الدخول'
      if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
        error = 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
      } else if (err.code === 'auth/wrong-password') {
        error = 'كلمة المرور غير صحيحة'
      } else if (err.code === 'auth/too-many-requests') {
        error = 'تم تجاوز عدد المحاولات، حاول لاحقاً'
      }
      return { success: false, error }
    }
  },

  register: async (name, email, phone, password) => {
    if (!isFirebaseConfigured) {
      return { success: false, error: 'Firebase غير مهيأ. يرجى إضافة مفاتيح Firebase في ملف .env' }
    }
    set({ loading: true })
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password)
      await updateProfile(cred.user, { displayName: name })
      const userData: User = {
        id: cred.user.uid,
        name,
        email,
        phone,
        role: 'user',
        createdAt: new Date().toISOString(),
      }
      await setDoc(doc(db, 'users', cred.user.uid), userData)
      set({ user: userData, firebaseUser: cred.user, isAuthenticated: true, loading: false })
      return { success: true }
    } catch (err: any) {
      set({ loading: false })
      let error = 'حدث خطأ في التسجيل'
      if (err.code === 'auth/email-already-in-use') {
        error = 'البريد الإلكتروني مسجل مسبقاً'
      } else if (err.code === 'auth/weak-password') {
        error = 'كلمة المرور ضعيفة جداً (6 أحرف على الأقل)'
      } else if (err.code === 'auth/invalid-email') {
        error = 'البريد الإلكتروني غير صالح'
      }
      return { success: false, error }
    }
  },

  logout: async () => {
    if (isFirebaseConfigured) {
      try { await signOut(auth) } catch { /* ignore */ }
    }
    set({ user: null, firebaseUser: null, isAuthenticated: false })
  },

  updateUserProfile: async (data) => {
    const user = get().user
    if (!user) return
    const updated = { ...user, ...data }
    if (isFirebaseConfigured) {
      await updateDoc(doc(db, 'users', user.id), data)
    }
    set({ user: updated })
  },
}))