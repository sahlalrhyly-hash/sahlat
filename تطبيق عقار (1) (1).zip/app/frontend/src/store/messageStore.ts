import { create } from 'zustand'
import {
  collection, addDoc, query, where, orderBy, onSnapshot,
  serverTimestamp, doc, updateDoc, getDocs, setDoc,
} from 'firebase/firestore'
import { db, isFirebaseConfigured } from '@/lib/firebase'
import { Message, Conversation } from '@/types'

interface MessageState {
  messages: Message[]
  conversations: Conversation[]
  loading: boolean
  sendMessage: (senderId: string, receiverId: string, propertyId: string, propertyTitle: string, text: string) => Promise<void>
  subscribeConversations: (userId: string) => () => void
  subscribeMessages: (conversationId: string) => () => void
  getConversations: (userId: string) => Conversation[]
  getMessages: (userId: string, otherUserId: string, propertyId: string) => Message[]
  markAsRead: (conversationId: string, userId: string) => Promise<void>
  getUnreadCount: (userId: string) => number
}

export const useMessageStore = create<MessageState>()((set, get) => ({
  messages: [],
  conversations: [],
  loading: false,

  sendMessage: async (senderId, receiverId, propertyId, propertyTitle, text) => {
    const convId = [senderId, receiverId].sort().join('-') + '-' + propertyId

    if (!isFirebaseConfigured) {
      // Demo mode - add locally
      const msg = { id: Date.now().toString(), senderId, receiverId, propertyId, text, createdAt: new Date().toISOString(), read: false }
      set({ messages: [...get().messages, msg] })
      return
    }

    // Add message to Firestore
    await addDoc(collection(db, 'messages'), {
      senderId,
      receiverId,
      propertyId,
      conversationId: convId,
      text,
      createdAt: serverTimestamp(),
      read: false,
    })

    // Update or create conversation
    const convRef = doc(db, 'conversations', convId)
    try {
      await updateDoc(convRef, {
        lastMessage: text,
        lastMessageAt: serverTimestamp(),
        [`unread_${receiverId}`]: (get().conversations.find(c => c.id === convId) as any)?.[`unread_${receiverId}`] + 1 || 1,
      })
    } catch {
      // Conversation doesn't exist, create it
      await setDoc(convRef, {
        participants: [senderId, receiverId],
        propertyId,
        propertyTitle,
        lastMessage: text,
        lastMessageAt: serverTimestamp(),
        [`unread_${senderId}`]: 0,
        [`unread_${receiverId}`]: 1,
        createdAt: serverTimestamp(),
      })
    }

    // Add notification for receiver
    await addDoc(collection(db, 'notifications'), {
      userId: receiverId,
      title: 'رسالة جديدة',
      body: `لديك رسالة جديدة بخصوص: ${propertyTitle}`,
      type: 'message',
      read: false,
      createdAt: serverTimestamp(),
    })
  },

  subscribeConversations: (userId) => {
    if (!isFirebaseConfigured) return () => {}
    const q = query(
      collection(db, 'conversations'),
      where('participants', 'array-contains', userId)
    )
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const conversations: Conversation[] = snapshot.docs.map(d => {
        const data = d.data()
        return {
          id: d.id,
          participants: data.participants,
          propertyId: data.propertyId,
          propertyTitle: data.propertyTitle,
          lastMessage: data.lastMessage,
          lastMessageAt: data.lastMessageAt?.toDate?.()?.toISOString?.() || new Date().toISOString(),
          unreadCount: data[`unread_${userId}`] || 0,
        }
      })
      conversations.sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime())
      set({ conversations })
    })
    return unsubscribe
  },

  subscribeMessages: (conversationId) => {
    if (!isFirebaseConfigured) return () => {}
    const q = query(
      collection(db, 'messages'),
      where('conversationId', '==', conversationId),
      orderBy('createdAt', 'asc')
    )
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const messages: Message[] = snapshot.docs.map(d => {
        const data = d.data()
        return {
          id: d.id,
          senderId: data.senderId,
          receiverId: data.receiverId,
          propertyId: data.propertyId,
          text: data.text,
          createdAt: data.createdAt?.toDate?.()?.toISOString?.() || new Date().toISOString(),
          read: data.read,
        }
      })
      set({ messages })
    })
    return unsubscribe
  },

  getConversations: (userId) => {
    return get().conversations.filter(c => c.participants.includes(userId))
  },

  getMessages: (userId, otherUserId, propertyId) => {
    return get().messages
  },

  markAsRead: async (conversationId, userId) => {
    try {
      const convRef = doc(db, 'conversations', conversationId)
      await updateDoc(convRef, { [`unread_${userId}`]: 0 })

      // Mark individual messages as read
      const q = query(
        collection(db, 'messages'),
        where('conversationId', '==', conversationId),
        where('receiverId', '==', userId),
        where('read', '==', false)
      )
      const snapshot = await getDocs(q)
      for (const msgDoc of snapshot.docs) {
        await updateDoc(doc(db, 'messages', msgDoc.id), { read: true })
      }
    } catch { /* ignore */ }

    set({
      conversations: get().conversations.map(c =>
        c.id === conversationId ? { ...c, unreadCount: 0 } : c
      ),
    })
  },

  getUnreadCount: (userId) => {
    return get().conversations
      .filter(c => c.participants.includes(userId))
      .reduce((sum, c) => sum + c.unreadCount, 0)
  },
}))