import { create } from 'zustand'
import {
  collection, addDoc, query, where, orderBy, onSnapshot,
  doc, updateDoc, getDocs, serverTimestamp, writeBatch,
} from 'firebase/firestore'
import { db, isFirebaseConfigured } from '@/lib/firebase'
import { Notification } from '@/types'

interface NotificationState {
  notifications: Notification[]
  loading: boolean
  subscribeNotifications: (userId: string) => () => void
  addNotification: (userId: string, title: string, body: string, type: Notification['type']) => Promise<void>
  markAsRead: (id: string) => Promise<void>
  markAllAsRead: (userId: string) => Promise<void>
  getNotifications: (userId: string) => Notification[]
  getUnreadCount: (userId: string) => number
}

export const useNotificationStore = create<NotificationState>()((set, get) => ({
  notifications: [],
  loading: false,

  subscribeNotifications: (userId) => {
    if (!isFirebaseConfigured) {
      set({ loading: false })
      return () => {}
    }
    set({ loading: true })
    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    )
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notifications: Notification[] = snapshot.docs.map(d => {
        const data = d.data()
        return {
          id: d.id,
          userId: data.userId,
          title: data.title,
          body: data.body,
          type: data.type,
          read: data.read,
          createdAt: data.createdAt?.toDate?.()?.toISOString?.() || new Date().toISOString(),
        }
      })
      set({ notifications, loading: false })
    }, () => {
      set({ loading: false })
    })
    return unsubscribe
  },

  addNotification: async (userId, title, body, type) => {
    if (!isFirebaseConfigured) return
    await addDoc(collection(db, 'notifications'), {
      userId,
      title,
      body,
      type,
      read: false,
      createdAt: serverTimestamp(),
    })
  },

  markAsRead: async (id) => {
    try {
      await updateDoc(doc(db, 'notifications', id), { read: true })
    } catch { /* ignore */ }
    set({
      notifications: get().notifications.map(n => n.id === id ? { ...n, read: true } : n),
    })
  },

  markAllAsRead: async (userId) => {
    try {
      const q = query(
        collection(db, 'notifications'),
        where('userId', '==', userId),
        where('read', '==', false)
      )
      const snapshot = await getDocs(q)
      const batch = writeBatch(db)
      snapshot.docs.forEach(d => {
        batch.update(doc(db, 'notifications', d.id), { read: true })
      })
      await batch.commit()
    } catch { /* ignore */ }
    set({
      notifications: get().notifications.map(n => n.userId === userId ? { ...n, read: true } : n),
    })
  },

  getNotifications: (userId) => get().notifications.filter(n => n.userId === userId),

  getUnreadCount: (userId) => get().notifications.filter(n => n.userId === userId && !n.read).length,
}))