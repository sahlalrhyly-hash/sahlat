import { create } from 'zustand'
import {
  collection, addDoc, updateDoc, deleteDoc, doc,
  query, orderBy, onSnapshot, serverTimestamp,
} from 'firebase/firestore'
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage'
import { db, storage, isFirebaseConfigured } from '@/lib/firebase'
import { Property } from '@/types'

const DEMO_PROPERTIES: Property[] = [
  {
    id: 'demo1', title: 'فيلا فاخرة في حي الملقا', description: 'فيلا مودرن بتصميم عصري مع مسبح خاص وحديقة واسعة',
    type: 'villa', purpose: 'sale', price: 3500000, area: 450, rooms: 6, bathrooms: 5,
    city: 'الرياض', district: 'الملقا', address: 'شارع الأمير محمد بن سلمان',
    lat: 24.8, lng: 46.6,
    images: ['https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800', 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800'],
    videos: [], features: ['مسبح', 'حديقة', 'مواقف سيارات', 'غرفة خادمة'],
    ownerId: 'demo-user', ownerName: 'أحمد العقاري', ownerPhone: '0551234567',
    status: 'active', views: 245, createdAt: '2024-07-01T10:00:00Z',
  },
  {
    id: 'demo2', title: 'شقة مفروشة للإيجار في النرجس', description: 'شقة مفروشة بالكامل قريبة من جميع الخدمات',
    type: 'apartment', purpose: 'rent', price: 45000, area: 150, rooms: 3, bathrooms: 2,
    city: 'الرياض', district: 'النرجس', address: 'طريق الملك سلمان',
    lat: 24.85, lng: 46.65,
    images: ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800', 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800'],
    videos: [], features: ['مفروشة', 'مكيفات', 'مطبخ مجهز', 'قريبة من المدارس'],
    ownerId: 'demo-user2', ownerName: 'محمد الشمري', ownerPhone: '0559876543',
    status: 'active', views: 180, createdAt: '2024-07-05T14:00:00Z',
  },
  {
    id: 'demo3', title: 'أرض تجارية على طريق رئيسي', description: 'أرض تجارية بموقع استراتيجي مناسبة لمشروع تجاري',
    type: 'land', purpose: 'sale', price: 8000000, area: 2000, rooms: 0, bathrooms: 0,
    city: 'جدة', district: 'الحمراء', address: 'طريق الملك عبدالعزيز',
    lat: 21.5, lng: 39.2,
    images: ['https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800'],
    videos: [], features: ['واجهة تجارية', 'على طريق رئيسي', 'زاوية'],
    ownerId: 'demo-user3', ownerName: 'خالد المالكي', ownerPhone: '0541112233',
    status: 'active', views: 320, createdAt: '2024-06-20T09:00:00Z',
  },
  {
    id: 'demo4', title: 'دوبلكس عائلي في حي الياسمين', description: 'دوبلكس واسع مناسب للعائلات الكبيرة مع مدخل خاص',
    type: 'villa', purpose: 'sale', price: 2200000, area: 350, rooms: 5, bathrooms: 4,
    city: 'الرياض', district: 'الياسمين', address: 'شارع الأمير فيصل',
    lat: 24.82, lng: 46.63,
    images: ['https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800', 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800'],
    videos: [], features: ['مدخل خاص', 'سطح', 'مجلس', 'غرفة سائق'],
    ownerId: 'demo-user', ownerName: 'أحمد العقاري', ownerPhone: '0551234567',
    status: 'active', views: 156, createdAt: '2024-07-10T11:00:00Z',
  },
  {
    id: 'demo5', title: 'مكتب تجاري في برج المملكة', description: 'مكتب مجهز بالكامل في موقع مميز بإطلالة بانورامية',
    type: 'office', purpose: 'rent', price: 120000, area: 200, rooms: 4, bathrooms: 2,
    city: 'الرياض', district: 'العليا', address: 'برج المملكة - الطابق 30',
    lat: 24.71, lng: 46.67,
    images: ['https://images.unsplash.com/photo-1497366216548-37526070297c?w=800'],
    videos: [], features: ['إطلالة بانورامية', 'مواقف VIP', 'استقبال', 'قاعة اجتماعات'],
    ownerId: 'demo-user4', ownerName: 'عبدالله السعيد', ownerPhone: '0567778899',
    status: 'active', views: 89, createdAt: '2024-07-12T16:00:00Z',
  },
]

interface PropertyState {
  properties: Property[]
  favorites: string[]
  loading: boolean
  subscribeProperties: () => () => void
  addProperty: (property: Omit<Property, 'id' | 'createdAt' | 'views'>, imageFiles: File[], videoFiles: File[]) => Promise<string>
  updateProperty: (id: string, data: Partial<Property>, newImageFiles?: File[], newVideoFiles?: File[]) => Promise<void>
  deleteProperty: (id: string) => Promise<void>
  toggleFavorite: (id: string) => void
  incrementViews: (id: string) => void
  getPropertyById: (id: string) => Property | undefined
  getUserProperties: (userId: string) => Property[]
  searchProperties: (query: string, filters?: any) => Property[]
}

async function uploadFiles(files: File[], folder: string): Promise<string[]> {
  if (!isFirebaseConfigured) return []
  const urls: string[] = []
  for (const file of files) {
    const fileName = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2)}_${file.name}`
    const storageRef = ref(storage, fileName)
    await uploadBytes(storageRef, file)
    const url = await getDownloadURL(storageRef)
    urls.push(url)
  }
  return urls
}

export const usePropertyStore = create<PropertyState>()((set, get) => ({
  properties: [],
  favorites: JSON.parse(localStorage.getItem('aqar-favorites') || '[]'),
  loading: false,

  subscribeProperties: () => {
    if (!isFirebaseConfigured) {
      // Demo mode - use local data
      set({ properties: DEMO_PROPERTIES, loading: false })
      return () => {}
    }
    set({ loading: true })
    const q = query(collection(db, 'properties'), orderBy('createdAt', 'desc'))
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const properties: Property[] = snapshot.docs.map(d => ({
        ...d.data(),
        id: d.id,
        createdAt: d.data().createdAt?.toDate?.()?.toISOString?.() || d.data().createdAt || new Date().toISOString(),
      })) as Property[]
      set({ properties, loading: false })
    }, () => {
      set({ properties: DEMO_PROPERTIES, loading: false })
    })
    return unsubscribe
  },

  addProperty: async (property, imageFiles, videoFiles) => {
    if (!isFirebaseConfigured) {
      throw new Error('Firebase غير مهيأ - يرجى إضافة مفاتيح Firebase')
    }
    set({ loading: true })
    try {
      const imageUrls = await uploadFiles(imageFiles, 'properties/images')
      const videoUrls = await uploadFiles(videoFiles, 'properties/videos')
      const docRef = await addDoc(collection(db, 'properties'), {
        ...property,
        images: imageUrls,
        videos: videoUrls,
        ownerWhatsapp: property.ownerWhatsapp || property.ownerPhone,
        createdAt: serverTimestamp(),
        views: 0,
      })
      set({ loading: false })
      return docRef.id
    } catch (err) {
      set({ loading: false })
      throw err
    }
  },

  updateProperty: async (id, data, newImageFiles, newVideoFiles) => {
    if (!isFirebaseConfigured) return
    set({ loading: true })
    try {
      const updateData: any = { ...data }
      if (newImageFiles && newImageFiles.length > 0) {
        const newImageUrls = await uploadFiles(newImageFiles, 'properties/images')
        updateData.images = [...(data.images || []), ...newImageUrls]
      }
      if (newVideoFiles && newVideoFiles.length > 0) {
        const newVideoUrls = await uploadFiles(newVideoFiles, 'properties/videos')
        updateData.videos = [...(data.videos || []), ...newVideoUrls]
      }
      delete updateData.id
      delete updateData.createdAt
      await updateDoc(doc(db, 'properties', id), updateData)
      set({ loading: false })
    } catch (err) {
      set({ loading: false })
      throw err
    }
  },

  deleteProperty: async (id) => {
    if (isFirebaseConfigured) {
      await deleteDoc(doc(db, 'properties', id))
    }
    set({ properties: get().properties.filter(p => p.id !== id) })
  },

  toggleFavorite: (id) => {
    const favorites = get().favorites
    const updated = favorites.includes(id) ? favorites.filter(f => f !== id) : [...favorites, id]
    localStorage.setItem('aqar-favorites', JSON.stringify(updated))
    set({ favorites: updated })
  },

  incrementViews: async (id) => {
    const property = get().properties.find(p => p.id === id)
    if (property && isFirebaseConfigured) {
      try {
        await updateDoc(doc(db, 'properties', id), { views: (property.views || 0) + 1 })
      } catch { /* ignore */ }
    }
  },

  getPropertyById: (id) => get().properties.find(p => p.id === id),

  getUserProperties: (userId) => get().properties.filter(p => p.ownerId === userId),

  searchProperties: (queryStr, filters) => {
    let results = get().properties.filter(p => p.status === 'active')
    if (queryStr) {
      const q = queryStr.toLowerCase()
      results = results.filter(p => p.title.includes(q) || p.city.includes(q) || p.district.includes(q))
    }
    if (filters?.type) results = results.filter(p => p.type === filters.type)
    if (filters?.purpose) results = results.filter(p => p.purpose === filters.purpose)
    if (filters?.city) results = results.filter(p => p.city === filters.city)
    if (filters?.minPrice) results = results.filter(p => p.price >= filters.minPrice)
    if (filters?.maxPrice) results = results.filter(p => p.price <= filters.maxPrice)
    if (filters?.minArea) results = results.filter(p => p.area >= filters.minArea)
    if (filters?.rooms) results = results.filter(p => p.rooms >= filters.rooms)
    return results
  },
}))