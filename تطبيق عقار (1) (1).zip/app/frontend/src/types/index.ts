export interface User {
  id: string
  name: string
  email: string
  phone: string
  avatar?: string
  role: 'user' | 'admin'
  createdAt: string
}

export interface Property {
  id: string
  title: string
  description: string
  type: 'apartment' | 'villa' | 'land' | 'office' | 'shop' | 'building' | 'farm'
  purpose: 'sale' | 'rent'
  price: number
  area: number
  rooms: number
  bathrooms: number
  city: string
  district: string
  address: string
  lat: number
  lng: number
  images: string[]
  videos?: string[]
  features: string[]
  ownerId: string
  ownerName: string
  ownerPhone: string
  ownerWhatsapp?: string
  status: 'active' | 'sold' | 'rented' | 'pending'
  createdAt: string
  views: number
}

export interface Message {
  id: string
  senderId: string
  receiverId: string
  propertyId: string
  text: string
  createdAt: string
  read: boolean
}

export interface Conversation {
  id: string
  participants: string[]
  propertyId: string
  propertyTitle: string
  lastMessage: string
  lastMessageAt: string
  unreadCount: number
}

export interface Notification {
  id: string
  userId: string
  title: string
  body: string
  type: 'message' | 'property' | 'system'
  read: boolean
  createdAt: string
}